<?php
$panel    = 'title_bar';
$priority = 1;

Smilepure_Kirki::add_section( 'title_bar', array(
	'title'    => esc_html__( 'General', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'title_bar_01', array(
	'title'    => esc_html__( 'Style 01', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'title_bar_02', array(
	'title'    => esc_html__( 'Style 02', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'title_bar_03', array(
	'title'    => esc_html__( 'Style 03', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'title_bar_04', array(
	'title'    => esc_html__( 'Style 04', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'title_bar_05', array(
	'title'    => esc_html__( 'Style 05', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'title_bar_06', array(
	'title'    => esc_html__( 'Style 06', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'title_bar_07', array(
	'title'    => esc_html__( 'Style 07', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );
