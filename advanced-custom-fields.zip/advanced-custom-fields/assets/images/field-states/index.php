<?php
// There are many ways to WordPress.
