<?php

/**
 * Template Library Header Template
 */
if (!defined('ABSPATH')) exit; // Exit if accessed directly
?>
<div id="bdt-elementpack-template-library-tabs-items"></div>