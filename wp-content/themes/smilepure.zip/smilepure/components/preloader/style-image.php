<div class="sk-image">
	<img src="<?php echo esc_url( Smilepure::setting( 'preloader_image' ) ); ?>"
	     alt="<?php echo esc_attr( 'preloader', 'smilepure' ); ?>"/>
</div>
