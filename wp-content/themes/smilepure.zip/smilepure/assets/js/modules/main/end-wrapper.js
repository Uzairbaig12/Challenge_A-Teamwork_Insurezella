	}( jQuery )
);
