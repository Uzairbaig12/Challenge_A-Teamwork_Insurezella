<div id="page-navigation" <?php Smilepure::navigation_class(); ?>>
	<nav id="menu" class="menu menu--primary">
		<?php Smilepure::menu_primary(); ?>
	</nav>
</div>
