=== Sellkit ===
Contributors: artbees
Tags: sellkit-pro
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.0
Stable tag: 1.8.2
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Core functionalities for Jupiter X theme.

== Description ==

Sellkit plugin.

== Installation ==

1. Install using the WordPress built-in Plugin installer, or Extract the zip file and drop the contents in the `wp-content/plugins/` directory of your WordPress installation.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==
= 1.8.2 - 2024-07-15 =
* Bug Fix: Fixed translation issue in the Product Filter widget.
* Bug Fix: Fixed a PHP fatal error in the Price filter on the Product Filter widget.

= 1.8.0 - 2024-05-29 =
* Bug Fix: Fixed translation issue in the Product Filter widget.
* Bug Fix: Fixed Smart Coupon issues.
* Improvement: Updated the list of countries in the Visitor Country condition.

= 1.7.8 - 2024-05-01 =
* Bug Fix: Fixed Dynamic Discounts issue on Apple Pay.
* Bug Fix: Fixed issues on Dynamic Discounts options.
* Bug Fix: Fixed issue on update notice.
* Feature: Added Cart Item Count condition.
* Feature: Added Purchased Product Count condition.

= 1.7.5 - 2024-4-09 =
* Bug Fix: Fixed Checkout widget issues.
* Improvement: Improved Product Filter widget to be compatible with JupiterX Shopping Cart widget.

= 1.7.4 - 2024-03-07 =
* Bug Fix: Fixed incompatibility issues with PHP 8.2.
* Bug Fix: Fixed Autocomplete Address issue in the Checkout widget.

= 1.7.2 - 2023-11-27 =
* Bug Fix: Fixed typography issues in Funnel conditions.
* Improvement: Improved Dynamic Discount to be compatible with JupiterX Cart widget.

= 1.7.1 - 2023-10-03 =
* Bug Fix: Fixed UX issue when WooCommerce plugin is deactivated.

= 1.7.0 - 2023-08-15 =
* Bug Fix: Fixed border-radius issue on Color Swatch.
* Improvement: Improved Swatches loading speed on single product page.

= 1.6.8 - 2023-07-13 =
* Bug Fix: Fixed minor issues and improvements.

= 1.6.7 - 2023-06-14 =
* Bug Fix: Fixed Image Swatches size on Product Filter widget.
* Improvement: Improved Product Filter widget to be compatible with archive pages.
* Feature: Added Checkmark to Color Swatches on Product Filter widget.
* Feature: Added new settings to Product Filter widget.

= 1.6.4 - 2023-05-08 =
* Bug Fix: Fixed attribute swatches issues in catalog page.
* Bug Fix: Fixed Image Swatches image size.
* Bug Fix: Fixed Image/Color Swatches add new term issue.
* Improvement: Improved Swatches load on edit product page.
* Improvement: Improved Image Swatches settings.
* Improvement: Improved attribute swatches to be compatible with Motion Effect of JupiterX & Elementor Pro.
* Improvement: Improved Product Filter to be compatible with query of JupiterX Products widget.
* Improvement: Improved Product Filter to be compatible with Featured Image Hover of JupiterX Products widget.
* Improvement: Improved Product Filter to be compatible with Elementor Inline Font Icons.
* Improvement: Improved Product Filter preloader.
* Feature: Added 'Dropdown' swatch type to swatches list.

= 1.6.0 - 2023-04-12 =
* Bug Fix: Fixed Product Filter widget issues.
* Bug Fix: Fixed attribute swatches issues in edit product page.
* Improvement: Improved image swatches.
* Improvement: Improved Product Filter widget.
* Feature: Added sorting to Product Filter widget filters.

= 1.5.5 - 2023-02-20 =
* Bug Fix: Fixed attribute swatches issues.
* Bug Fix: Fixed Smart Coupons "Apply to products on sale" issue.
* Improvement: Improved Product Filter widget.
* Improvement: Improved attribute swatches performance.

= 1.5.3 - 2023-01-18 =
* Bug Fix: Fixed Elementor deprecated notices.

= 1.5.2 - 2022-01-05 =
* Bug Fix: Fixed product filter widget issue.

= 1.5.1 - 2022-12-12 =
* Bug Fix: Fixed dependency alert issue.

= 1.5.0 - 2022-10-14 =
* Bug Fix: Fixed database names errors with hyphen.
* Feature: Added some extra conditions to the funnels.

= 1.3.0 - 2022-10-03 =
* Bug Fix: Fixed attribute swatches conflict with woocommerce subscription.
* Bug Fix: Fixed plugin data deletion on multisite.

= 1.2.9 - 2022-09-06 =
* Bug Fix: Fixed dependency issues.
* Bug Fix: Fixed product filter icons incompatibility with Menu icons.
* Bug Fix: Fixed some typos.
* Bug Fix: Fixed attribute swatches small issues in front-end.

= 1.2.7 - 2022-08-18 =
* Bug Fix: Fixed repeat discount switch issue.
* Bug Fix: Fixed product filter incompatibility with Jet woo builder.

= 1.2.6 - 2022-08-02 =
* Bug Fix: Fixed geolocation conditions issues.
* Bug Fix: Fixed priority issue for smart notices.
* Bug Fix: Fixed numeric attribute issue in swatches.
* Bug Fix: Fixed some typos in conditions.
* Bug Fix: Fixed attribute swatches issue in Claue theme.
* Bug Fix: Fixed some issue in product filter.
* Improvement: Improved country and city conditions.
* Improvement: Improved swatches design.

= 1.2.3 - 2022-05-23 =
* Feature: Added some new conditions to the conditions component.
* Feature: Added Geolocation service.
* Bug Fix: Fixed translation issues.
* Bug Fix: Fixed date picker issue in add new coupon form.
* Bug Fix: Fixed global attribute swatches issues.
* Bug Fix: Fixed product filter database issue.
* Improvement: Improved the personalised coupon widget name.
* Improvement: Improved smart coupon visibility.

= 1.2.4 - 2022-06-28 =
* Bug Fix: Fixed plugin data deletion issue.
* Bug Fix: Fixed extra geo location notice issue.
* Bug Fix: Fixed image attribute issue in swatches feature.
* Bug Fix: Fixed some small translation issues.
* Bug Fix: Fixed an incompatibility between product filter and product archive page.
* Improvement: Improved type class of the parent wrapper of variation swatches.

= 1.2.2 - 2022-04-28 =
* Bug Fix: Fixed analytics style issues.
* Bug Fix: Fixed some deprecated notices regarding Elementor plugin.
* Improvement: Improved features names.

= 1.2.1 - 2022-04-07 =
* Bug Fix: Fixed the clear button issue in activate swatched widget.
* Bug Fix: Fixed some bugs in PHP 7.2.
* Bug Fix: Fixed dynamic keywords issues in thankyou page.
* Bug Fix: Fixed date picker value in conditions component.
* Bug Fix: Fixed and issue in alerts when the conditions was empty.
* Improvement: Removed FILTER_SANITIZE_STRING which is deprecated in PHP 8.1.

= 1.0.0 =
* Initial release
