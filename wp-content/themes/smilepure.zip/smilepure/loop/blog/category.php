<?php if ( has_category() ) : ?>
	<div class="post-categories">
		<?php the_category( ', ' ); ?>
	</div>
<?php endif; ?>
