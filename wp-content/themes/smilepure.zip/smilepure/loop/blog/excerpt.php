<div class="post-excerpt">
	<?php Smilepure_Templates::excerpt( array(
		'limit' => 100,
		'type'  => 'character',
	) ); ?>
</div>
