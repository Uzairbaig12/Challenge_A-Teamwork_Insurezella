<?php

abstract class UEHttpException extends Exception{

	//

}
