<div id="page-navigation" <?php Smilepure::navigation_class(); ?>>
	<nav id="menu" class="menu menu--primary">
		<?php Smilepure::menu_primary( array(
			'menu_class' => 'menu__container sm sm-simple sm-vertical',
		) ); ?>
	</nav>
</div>
