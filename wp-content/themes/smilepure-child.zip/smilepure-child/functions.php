<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue child scripts
 */
if ( ! function_exists( 'Smilepure_child_enqueue_scripts' ) ) {
	function Smilepure_child_enqueue_scripts() {
		wp_enqueue_style( 'smilepure-style', SMILEPURE_THEME_URI . "/style.css" );
		wp_enqueue_style( 'smilepure-child-style', get_stylesheet_directory_uri() . '/style.css', array( 'smilepure-style' ), wp_get_theme()->get( 'Version' ) );
	}
}
add_action( 'wp_enqueue_scripts', 'Smilepure_child_enqueue_scripts' );
