<?php
  if (!defined('ABSPATH')) exit; // Exit if accessed directly
;?>
<button class="elementor-template-library-template-action bdt-elementpack-template-library-template-insert elementor-button elementor-button-success">
    <i class="eicon-file-download"></i>
    <span class="elementor-button-title"><?php esc_html_e( 'Insert', 'bdthemes-element-pack' ); ?></span>
</button>
