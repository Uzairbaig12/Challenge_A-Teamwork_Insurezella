<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin installation and activation for WordPress themes
 */
if ( ! class_exists( 'Smilepure_Register_Plugins' ) ) {
	class Smilepure_Register_Plugins {

		public function __construct() {
			add_filter( 'insight_core_tgm_plugins', array( $this, 'register_required_plugins' ) );
		}

		public function register_required_plugins() {
			/*
			 * Array of plugin arrays. Required keys are name and slug.
			 * If the source is NOT from the .org repo, then source is also required.
			 */
			$plugins = array(
				array(
					'name'     => esc_html__( 'Insight Core', 'smilepure' ),
					'slug'     => 'insight-core',
					'source'   => 'https://www.googleapis.com/drive/v3/files/1acW6VEv3RiQB9zC37jgLKK8e8pe5HTP6?alt=media&key=AIzaSyBQsxIg32Eg17Ic0tmRvv1tBZYrT9exCwk',
					'version'  => '2.4.2',
					'required' => true,
				),
				array(
					'name'     => esc_html__( 'WPBakery Page Builder', 'smilepure' ),
					'slug'     => 'js_composer',
					'source'   => 'https://www.googleapis.com/drive/v3/files/1A8-G_73QK3UBVUKdU86JitP8OUJKcQTt?alt=media&key=AIzaSyBQsxIg32Eg17Ic0tmRvv1tBZYrT9exCwk',
					'version'  => '6.9.0',
					'required' => true,
				),
				array(
					'name'     => esc_html__( 'WPBakery Page Builder (Visual Composer) Clipboard', 'smilepure' ),
					'slug'     => 'vc_clipboard',
					'source'   => 'https://www.googleapis.com/drive/v3/files/1fvaqD_UY7pe3Zwz_cUMGmsyIA6Xx_l9d?alt=media&key=AIzaSyBQsxIg32Eg17Ic0tmRvv1tBZYrT9exCwk',
					'version'  => '5.0.3',
					'required' => false,
				),
				array(
					'name'     => esc_html__( 'Booked', 'smilepure' ),
					'slug'     => 'booked',
					'source'   => 'https://api.thememove.com/download/booked-2.3.5-snzfAHtlX0.zip',
					'version'  => '2.3.5',
					'required' => false,
				),
				array(
					'name'     => esc_html__( 'Timetable and Event Schedule', 'smilepure' ),
					'slug'     => 'mp-timetable',
					'required' => false,
				),
				array(
					'name'     => esc_html__( 'Contact Form 7', 'smilepure' ),
					'slug'     => 'contact-form-7',
					'required' => false,
				),
				array(
					'name'     => esc_html__( 'MailChimp for WordPress', 'smilepure' ),
					'slug'     => 'mailchimp-for-wp',
					'required' => false,
				),
				array(
					'name' => esc_html__( 'WooCommerce', 'smilepure' ),
					'slug' => 'woocommerce',
				),
				array(
					'name'     => esc_html__( 'WooCommerce Smart Quick View', 'smilepure' ),
					'slug'     => 'woo-smart-quick-view',
					'required' => false,
				),
				array(
					'name' => esc_html__( 'WPC Smart Compare for WooCommerce', 'smilepure' ),
					'slug' => 'woo-smart-compare',
				),
				array(
					'name' => esc_html__( 'WPC Smart Wishlist for WooCommerce', 'smilepure' ),
					'slug' => 'woo-smart-wishlist',
				),
				array(
					'name'     => esc_html__( 'Revolution Slider', 'smilepure' ),
					'slug'     => 'revslider',
					'source'   => 'https://www.googleapis.com/drive/v3/files/1AM1FS_OecPXtKm1p8oK-3cEhMxOYxXdr?alt=media&key=AIzaSyBQsxIg32Eg17Ic0tmRvv1tBZYrT9exCwk',
					'version'  => '6.5.20',
					'required' => true,
				),
				array(
					'name'    => esc_html__( 'Instagram Feed', 'smilepure' ),
					'slug'    => 'elfsight-instagram-feed-cc',
					'source'  => 'https://api.thememove.com/download/elfsight-instagram-feed-cc-4.0.2-dYYYZeP8Zo.zip',
					'version' => '4.0.2',
				),
			);

			return $plugins;
		}

	}

	new Smilepure_Register_Plugins();
}
