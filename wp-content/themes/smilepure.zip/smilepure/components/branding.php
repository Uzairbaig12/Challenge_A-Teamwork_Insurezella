<div <?php Smilepure::branding_class(); ?>>
	<div class="branding__logo">
		<?php Smilepure::branding_logo(); ?>
	</div>
</div>
