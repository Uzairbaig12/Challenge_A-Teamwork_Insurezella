<?php
/**
 * The template for displaying the footer.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package SmilePure
 * @since   1.0
 */

?>
</div><!-- /.content-wrapper -->
<?php get_template_part( 'components/footer' ); ?>
</div><!-- /.site -->
<?php wp_footer(); ?>
</body>
</html>
