<?php
$panel    = 'top_bar';
$priority = 1;

Smilepure_Kirki::add_section( 'top_bar', array(
	'title'    => esc_html__( 'General', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_01', array(
	'title'    => esc_html__( 'Top Bar Style 01', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_02', array(
	'title'    => esc_html__( 'Top Bar Style 02', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_03', array(
	'title'    => esc_html__( 'Top Bar Style 03', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_04', array(
	'title'    => esc_html__( 'Top Bar Style 04', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_05', array(
	'title'    => esc_html__( 'Top Bar Style 05', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_06', array(
	'title'    => esc_html__( 'Top Bar Style 06', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_07', array(
	'title'    => esc_html__( 'Top Bar Style 07', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_08', array(
	'title'    => esc_html__( 'Top Bar Style 08', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_09', array(
	'title'    => esc_html__( 'Top Bar Style 09', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_10', array(
	'title'    => esc_html__( 'Top Bar Style 10', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_11', array(
	'title'    => esc_html__( 'Top Bar Style 11', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );

Smilepure_Kirki::add_section( 'top_bar_style_12', array(
	'title'    => esc_html__( 'Top Bar Style 12', 'smilepure' ),
	'panel'    => $panel,
	'priority' => $priority ++,
) );
